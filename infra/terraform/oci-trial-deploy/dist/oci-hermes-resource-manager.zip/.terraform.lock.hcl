# This file is maintained automatically by "terraform init".
# Manual edits may be lost in future updates.

provider "registry.terraform.io/oracle/oci" {
  version     = "8.23.0"
  constraints = ">= 6.0.0"
  hashes = [
    "h1:pdG14kh/kjy7NJzvneQSKNOGHLCpjdsbxgMKzCB3OmA=",
    "zh:3006f63241644b557ae80cafd4d954c3a24aa6f16e7d21b8224433993f2c9eb5",
    "zh:3035adb18aa91affe1e2efb02957200f268076cea0d12a412287e38850d86062",
    "zh:41e7151dc48661aa8584ed2539762b23bcad232859e62ea2357614798d56f7dd",
    "zh:46c729106ee7dd6dd8a550281b7bc37bf630a9c1704667a11671085d814d7a53",
    "zh:670d4a2c3969707c3dd5ca7d2c98ba2f76c584757436808e562b160b161c0d58",
    "zh:7273327664fdcf1759b4d7d8b463b4052e1003b6f53c50e76e012fda57f70a2c",
    "zh:76a4b602ddaa14f055b2703b5822942d849ed8b690c1bdeecaaa24a26891a18a",
    "zh:898cca18728cad43d493a1d14c356159c6841e217a8afd82842a2d85ef0c5915",
    "zh:9b12af85486a96aedd8d7984b0ff811a4b42e3d88dad1a3fb4c0b580d04fa425",
    "zh:afb807a113767ebdb1b79102387e27d609af3bec0894a0948dd1d5c8f81b851b",
    "zh:bbde8b1e9ae7ad2c6138dd1593146eedecb661156d661ad27e27d72d6a3e95ad",
    "zh:cdf443c5ce5caf5df803ae5ae5d5125d3167c9a4cb6fdd0bc4aa1ddae56167f3",
    "zh:d8e84d66866874258c55005dd3975618b657afed1c93ce00dcb034a13b148f55",
    "zh:dd58cd489b2e19bd2042c40082e0d928454147722946b03b97967ed9b5c72244",
    "zh:e9cc5b0ad0bdb6aefa7895c4432f80779ce38d349474f61103cc998f15d175ab",
  ]
}
